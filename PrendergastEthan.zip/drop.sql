drop table event_subtypes;
drop table cyber_events;
drop table naics;
drop table isocc;
