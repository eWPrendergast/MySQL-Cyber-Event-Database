# table descriptions
describe naics;
describe isocc;
describe cyber_events;
describe event_subtypes;

# table populations
select count(*) AS industries from naics;
select count(*) AS countries from isocc;
select count(*) AS events from cyber_events;
select count(*) AS events_and_subtypes from event_subtypes;

# Query 1 reflection
select c_name target_country_name, e_date, e_id, e_type, naics_description industry_description, motive, actor_country
from naics N join (cyber_events CE join isocc I on CE.target_country = I.c_code) on N.naics_code = CE.industry_code;

# Query 1 answer
select c_name target_country_name, e_date, e_id, e_type, naics_description industry_description, motive
from naics N join (cyber_events CE join isocc I on CE.target_country = I.c_code) on N.naics_code = CE.industry_code
where CE.actor_country = 'USA'
order by CE.target_country, CE.e_date DESC;

# Query 1 comprehensiveness
select c_code country_code, c_name country_name, count(*) AS actorInstances
from isocc I join cyber_events CE on I.c_code = CE.actor_country
group by c_code;

# Query 2 reflection
select * from event_subtypes order by e_subtype;

# Query 2 answer
select e_subtype event_subtype, count(*) AS numberOfEvents
from event_subtypes
group by e_subtype
order by numberOfEvents DESC , e_subtype;

# Query 2 comprehensiveness
select distinct e_subtype from event_subtypes;
