create table naics(
	naics_code int primary key,
    naics_description varchar(255)
);

create table isocc(
	c_code char(3) primary key,
    c_name varchar(255) not null
);

create table cyber_events(
	e_id char(16) primary key,
    e_date char(10) not null,
    e_year int not null,
    e_month int not null,
    actor varchar(100) not null,
    actor_type varchar(50) not null,
    organization varchar(100) not null,
    industry_code int not null,
    motive varchar(50) not null,
    e_type char(20) not null,
    e_description varchar(500) not null,
    source_url varchar(200) not null,
    target_country char(3) not null,
    actor_country char(3) not null,
    foreign key (industry_code) references naics(naics_code),
    foreign key (target_country) references isocc(c_code),
    foreign key (actor_country) references isocc(c_code),
    check (actor_type = 'Criminal' OR actor_type = 'Nation-State' OR actor_type = 'Terrorist' OR 
    actor_type = 'Hacktivist' OR actor_type = 'Hobbyist' OR actor_type = 'Undetermined'),
    check (motive = 'Protest' OR motive = 'Sabotage' OR motive = 'Espionage' OR 
    motive = 'Financial' OR motive = 'Undetermined'),
    check (e_type = 'Disruptive' OR e_type = 'Exploitive' OR e_type = 'Mixed' OR e_type = 'Undetermined')
);

create table event_subtypes(
	e_id char(16) not null,
    e_subtype varchar(50) not null,
    primary key (e_id, e_subtype),
    foreign key (e_id) references cyber_events(e_id),
    check (e_subtype = 'Message Manipulation' OR e_subtype = 'External Denial of Service' OR 
    e_subtype = 'Data Attack' OR e_subtype = 'Internal Denial of Service' OR e_subtype = 'Physical Attack' OR 
    e_subtype = 'Exploitation of Sensors' OR e_subtype = 'Exploitation of End Host' OR 
    e_subtype = 'Exploitation of Network Infrastructure' OR e_subtype = 'Exploitation of Application Server' OR 
    e_subtype = 'Exploitation of Data in Transit' OR e_subtype = 'Undetermined')
);